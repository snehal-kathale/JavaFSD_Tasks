public class MyBank {

}
class SBI extends MyBank {
    private String IFSC;
    private int AccNumber;
    private String Name;

    public SBI(String IFSC, int AccNumber, String Name) {
        this.IFSC = IFSC;
        this.AccNumber = AccNumber;
        this.Name = Name;
    }

    public SBI() {

    }

    static void deposite() {
        System.out.println("Deposited from SBI");

    }

    public String getIFSC() {
        return IFSC;
    }

    public void setIFSC(String IFSC) {
        this.IFSC = IFSC;
    }

    public int getAccNumber() {
        return AccNumber;
    }

    public void setAccNumber(int accNumber) {
        AccNumber = accNumber;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    @Override
    public String toString() {
        return "SBI{" +
                "IFSC='" + IFSC + '\'' +
                ", AccNumber=" + AccNumber +
                ", Name='" + Name + '\'' +
                '}';
    }



    public static void main(String[] args) {
        SBI s = new SBI("SBIN000777", 12234578, "snehal");

        System.out.println("Account holder is"+  s.getName());
        System.out.println("IFSC code of your bank"+  s.getIFSC());
        System.out.println("your Account Number is"+  s.getAccNumber());
        deposite();

    }
}
