import React from 'react';
import Card from '@ps/star-ui/components/Card/Card';
import CardBody from '@ps/star-ui/components/Card/CardBody';
import { PropTypes } from 'prop-types';

import { Grid } from '@mui/material';

import NomineeForm from './NomineeForm';

const NomineeDetailsForm = (props) => {
  const { classes } = props;

  return (
    <Grid container className={classes.loginbottomStyle}>
      <Grid item md={8} xs={12} sm={10} className={classes.logincardView}>
        <Card style={{ padding: `0` }}>
          <CardBody className={classes.cardBodyClasses} style={{ padding: 44 }}>
            <NomineeForm />
          </CardBody>
        </Card>
      </Grid>
    </Grid>
  );
};
NomineeDetailsForm.propTypes = {
  classes: PropTypes.any.isRequired,
};
export default NomineeDetailsForm;
