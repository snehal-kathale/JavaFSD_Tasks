import React, { useState, useEffect } from 'react';
import dayjs from 'dayjs';
import {
  Button,
  FormControl,
  Grid,
  MenuItem,
  Select,
  TextField,
  Typography,
  InputLabel,
} from '@mui/material';
import UpdatePop from './UpdatePop';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { ApiService } from './Services/Api.Services';
import AlertBox from './AlertBox';
import { getLocalStorageItem } from 'app/util/localStorageHelper';

const OPTIONS_CONFIG = [
  { key: 'Brother', label: 'Brother' },
  { key: 'Mother', label: 'Mother' },
  { key: 'Cousin', label: 'Cousin' },
];
const typographyLabel = {
  fontWeight: 500,
  color: '#555555',
  fontSize: 20,
  lineHeight: 1.5,
};

const typographyValue = {
  fontWeight: 400,
  color: '#35488A',
  fontSize: 20,
  lineHeight: 1.5,
  textTransform: 'uppercase',
};
const splitName = (fullName) => {
  if (!fullName) {
    return {
      firstName: '',
      middleName: '',
      lastName: '',
    };
  }
  const name = fullName.split(' ');
  const firstName = name[0] || '';
  const middleName = name.slice(1, -1).join(' ');
  const lastName = name[name.length - 1] || '';
  return { firstName, middleName, lastName };
};
const NomineeForm = () => {
  const [nomineeName, setNomineeName] = useState(null);
  const [nomineeDob, setNomineeDob] = useState(null);
  const [nomineeRelation, setNomineeRelation] = useState(null);
  const [appointeeName, setAppointeeName] = useState(null);
  const [appointeeDob, setAppointeeDob] = useState(null);
  const [appointeeRelation, setAppointeeRelation] = useState(null);
  const [name, setName] = useState(null);
  const [age, setAge] = useState(null);
  const [coi, setCoi] = useState(null);
  const [updatePop, setUpdatePop] = useState(false);
  const [errAlert, setErrAlert] = useState(false);
  const [errMsg, setErrMsg] = useState('');
  const [disableButton, setDisableButton] = useState(true);
  const [options, setOptions] = useState([]);

  const getAgeFromDob = (dob) => {
    const startDate = dayjs(dob || new Date());
    const endDate = dayjs(new Date());
    const duration =
      startDate && endDate ? endDate.diff(startDate, 'year', true) : null;
    return duration;
  };

  const formatDate = (date, format = 'DD-MM-YYYY') => {
    if (date) {
      return dayjs(date).format(format);
    }
    return '';
  };

  useEffect(() => {
    const logindata = JSON.parse(getLocalStorageItem('loginData'));
    let params = {};
    params = {
      coiNumber: logindata.coiNumber,
      mobileNumber: logindata.mobileNo,
    };

    ApiService.postNomineeDetails(params)
      .then((response) => {
        if (response?.data?.isNomineeUpdated === 'N') {
          const fullName = response?.data;
          const { firstName, middleName, lastName } = fullName;
          setName(`${firstName} ${middleName} ${lastName}`);
          setAge(response?.data?.age);
          setCoi(response?.data?.coiNumber);
          const relationshipOptions = response?.data?.nomineeRelationship;
          setOptions(relationshipOptions);
        } else {
          setErrAlert(true);
          setErrMsg(response?.data?.errorMessage);
        }
      })
      .catch((error) => {
        setErrAlert(true);
        setErrMsg(error?.response?.data?.errorMessage);
      });
  }, []);
  useEffect(() => {
    if (!nomineeDob || (nomineeDob && getAgeFromDob(nomineeDob) < 18)) {
      if (
        nomineeName &&
        nomineeDob &&
        nomineeRelation &&
        appointeeName &&
        appointeeDob &&
        appointeeRelation
      ) {
        setDisableButton(false);
      } else {
        setDisableButton(true);
      }
    } else {
      if (nomineeName && nomineeDob && nomineeRelation) {
        setDisableButton(false);
      } else {
        setDisableButton(true);
      }
    }
  }, [
    nomineeName,
    nomineeDob,
    nomineeRelation,
    appointeeName,
    appointeeDob,
    appointeeRelation,
  ]);

  const handleUpdate = () => {
    let IfNomineeAge = false;
    if (!nomineeDob || (nomineeDob && getAgeFromDob(nomineeDob) < 18)) {
      IfNomineeAge = true;
    }
    let params = {};

    const nomineeFullName = splitName(nomineeName);
    const appointeeFullName = splitName(appointeeName);
    params = {
      coiNumber: coi,
      nomineeDetails: [
        {
          ...nomineeFullName,
          dob: formatDate(nomineeDob),
          relationshipWithInsuredId: nomineeRelation,
          nomineePercentage: '100',
          //removing appointee details if nominee age is  greater than 18
          ...(IfNomineeAge
            ? {
                appointee: {
                  ...appointeeFullName,
                  dob: formatDate(appointeeDob),
                  relationshipWithNomineeId: appointeeRelation,
                },
              }
            : {}),
        },
      ],
    };

    ApiService.postUpdateNominee(params)
      .then((response) => {
        if (response.status === 'Success') {
          setUpdatePop(true);
        } else {
          setErrAlert(true);
          setErrMsg(response?.data?.errorMessage);
        }
      })
      .catch((error) => {
        setErrAlert(true);
        setErrMsg(error?.response?.data?.errorMessage);
      });
  };
  const handleCLose = (value) => {
    setUpdatePop(false);
  };
  const handleAlertClose = () => {
    setErrAlert(false);
  };
  const handleNomineeDob = (value) => {
    setNomineeDob(value);
    const nomineeAge = getAgeFromDob(value);

    // resetting appointee details if age of nominee exceeds 18 years.
    if (nomineeAge && nomineeAge > 18) {
      setAppointeeName(null);
      setAppointeeDob(null);
      setAppointeeRelation(null);
    }
  };

  const fields = [
    {
      name: 'NameOfNominee',
      placeholder: 'Name Of The Nominee',
      type: 'text',
      setterFunc: setNomineeName,
      value: nomineeName,
    },
    {
      name: 'DateOfBirthForNominee',
      label: 'Date of Birth for Nominee',
      setterFunc: (value) => handleNomineeDob(value),
      value: nomineeDob,
      type: 'date',
    },
    {
      name: 'RelationshipWithInsured',
      placeholder: 'Relationship With Insured',
      type: 'select',
      options: [],
      setterFunc: setNomineeRelation,
      value: nomineeRelation,
    },
    {
      name: 'NameOfAppointee',
      placeholder: 'Name Of The Appointee',
      type: 'text',
      setterFunc: setAppointeeName,
      value: appointeeName,
      disabled: !nomineeDob || (nomineeDob && getAgeFromDob(nomineeDob) > 18),
    },
    {
      name: 'DateOfBirthForAppointee',
      label: 'Date of Birth for Appointee',
      setterFunc: setAppointeeDob,
      value: appointeeDob,
      disabled: !nomineeDob || (nomineeDob && getAgeFromDob(nomineeDob) > 18),
      type: 'date',
    },
    {
      name: 'ApponteeRelationship',
      placeholder: 'Appointee Relationship',
      type: 'select',
      options: [],
      setterFunc: setAppointeeRelation,
      value: appointeeRelation,
      disabled: !nomineeDob || (nomineeDob && getAgeFromDob(nomineeDob) > 18),
    },
  ];

  const handleElements = (field) => {
    switch (field.type) {
      case 'text':
        return (
          <TextField
            id='standard-basic'
            label={field.placeholder}
            variant='standard'
            fullWidth
            onChange={(e) => field.setterFunc(e.target.value)}
            value={field.value}
            disabled={field.disabled}
          />
        );
      case 'date':
        return (
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DatePicker
              className='custom-date-picker'
              label={field.label}
              onChange={(value) => field.setterFunc(value)}
              value={field.value}
              disabled={field.disabled}
              slotProps={{ textField: { fullWidth: true } }}
              disableFuture={true}
            />
          </LocalizationProvider>
        );
      case 'select':
        return (
          <FormControl fullWidth varient='standard' className='custom-select'>
            <InputLabel id='demo-simple-select-label'>
              {field.placeholder}
            </InputLabel>
            <Select
              labelId='demo-simple-select-label'
              id='demo-simple-select'
              variant='standard'
              onChange={(e) => field.setterFunc(e.target.value)}
              value={field.value}
              disabled={field.disabled}>
              {/* {OPTIONS_CONFIG.map((option) => (
                <MenuItem key={option.key} value={option.key}>
                  {option.label}
                </MenuItem>
              ))} */}
              <MenuItem value=''>None</MenuItem>
              {options.map((option) => (
                <MenuItem
                  key={option.relationshipId}
                  value={option.relationshipId}>
                  {option.relationshipName}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        );
      default:
        break;
    }
  };

  return (
    <div className='nomineeForm'>
      <div>
        <Grid item xs={12} style={{ textAlign: 'center' }}>
          <Typography
            style={{
              fontWeight: 500,
              fontSize: 24,
            }}>
            Enter Nominee Details
          </Typography>
        </Grid>

        <form
          obSubmit={(e) => {
            e.preventDefault();
          }}>
          <Grid
            container
            spacing={3}
            style={{
              marginTop: '8px',
              display: 'flex',
              justifyItems: 'center',
              '& label': {
                color: 'red',
              },
            }}
            xs={12}
            md={12}>
            <Grid item md={4.5} xs={12}>
              <Typography style={typographyLabel}>Name</Typography>
              <Typography style={typographyValue}>{name}</Typography>
            </Grid>
            <Grid item md={3} xs={12}>
              <Typography style={typographyLabel}>Age</Typography>
              <Typography style={typographyValue}>{age}</Typography>
            </Grid>
            <Grid item md={4.5} xs={12}>
              <Typography style={typographyLabel}>COI Number</Typography>
              <Typography style={typographyValue}>{coi}</Typography>
            </Grid>

            {fields.map((field, idx) => (
              <Grid
                item
                xs={12}
                md={4}
                key={idx}
                sx={{
                  '& .custom-date-picker .MuiFormLabel-root': {
                    left: '-15px',
                  },
                  '& .custom-select .MuiFormLabel-root': {
                    left: '-15px',
                  },
                  '& .custom-date-picker .MuiInputBase-input': {
                    padding: '12.6px 14px',
                  },
                }}>
                {handleElements(field)}
              </Grid>
            ))}
          </Grid>
          <Grid item style={{ display: 'flex', justifyContent: 'center' }}>
            <Button
              onClick={handleUpdate}
              size='large'
              variant='contained'
              disabled={disableButton}
              style={{
                borderRadius: '24px',
                marginTop: 30,
                width: '30%',
                backgroundColor: disableButton ? '#7C88B3' : '#35488A',
                color: '#ffff',
              }}>
              Update
            </Button>
          </Grid>
        </form>
      </div>
      {setUpdatePop ? (
        <UpdatePop
          open={updatePop}
          handleClose={() => {
            handleCLose();
          }}
        />
      ) : (
        ''
      )}
      {setErrAlert ? (
        <AlertBox
          errMsg={errMsg}
          errAlert={errAlert}
          onClick={() => {
            handleAlertClose();
          }}
        />
      ) : (
        ''
      )}
    </div>
  );
};

export default NomineeForm;
