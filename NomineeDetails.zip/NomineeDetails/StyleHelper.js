import React from 'react';
import { NativeSelect, InputBase } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
export const getBootstrapInput = () => {
  return withStyles((theme) => ({
    root: {
      'label + &': {
        opacity: 0.5,
      },
    },
    overrides: {
      MuiNativeSelect: {
        root: {
          height: '17px',
          marginTop: '7px',
        },
      },
    },
    input: {
      borderRadius: 4,
      position: 'relative',
      backgroundColor: theme.palette.background.paper,
      border: '1px solid #ced4da',
      fontSize: 14,
      height: '18px',
      marginTop: '7px',
      width: '100%',
      padding: '10px 26px 10px 12px',
      transition: theme.transitions.create(['border-color', 'box-shadow']),
      // Use the system font instead of the default Roboto font.
      fontFamily: [
        '-apple-system',
        'BlinkMacSystemFont',
        '"Segoe UI"',
        'Roboto',
        '"Helvetica Neue"',
        'Arial',
        'sans-serif',
        '"Apple Color Emoji"',
        '"Segoe UI Emoji"',
        '"Segoe UI Symbol"',
      ].join(','),
      '&:focus': {
        borderRadius: 4,
        borderColor: '#80bdff',
        boxShadow: '0 0 0 0.2rem rgba(0,123,255,.25)',
      },
    },
  }))(InputBase);
};

const BootstrapInput = getBootstrapInput();

export const DropDown = (props) => {
  const { options, placeholder } = props;

  return (
    <NativeSelect
      style={{
        fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
        color: 'rgba(0, 0, 0, 0.54)',
        width: '100%',
      }}
      variant='standard'
      // input={<BootstrapInput />}
      placeholder={placeholder}
      {...props}>
      {options.map((item) => (
        <option
          placeholder={placeholder}
          style={{
            fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
            color: 'rgba(0, 0, 0, 0.54)',
          }}
          key={item.key}
          value={item.key}>
          {item.label}
        </option>
      ))}
    </NativeSelect>
  );
};
