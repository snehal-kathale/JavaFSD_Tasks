import React, { useState } from 'react';
import Stack from '@mui/material/Stack';
import MuiAlert from '@mui/material/Alert';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import Collapse from '@mui/material/Collapse';

const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant='filled' {...props} />;
});
const AlertBox = (props) => {
  const { errAlert, onClick, errMsg } = props;
  setTimeout(onClick, 5000);
  return (
    <Stack
      spacing={2}
      sx={{ width: '100%', display: 'flex', justifyContent: 'center' }}>
      <Collapse in={errAlert}>
        <Alert
          severity='error'
          action={
            <IconButton
              aria-label='close'
              color='inherit'
              size='small'
              onClick={() => {
                onClick();
              }}>
              <CloseIcon fontSize='inherit' />
            </IconButton>
          }
          sx={{ mb: 2 }}>
          {errMsg}
        </Alert>
      </Collapse>
    </Stack>
  );
};
export default AlertBox;
