import React, { useEffect, useState } from 'react';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { PORTAL_FLAG } from 'app/util/Config';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
  parentDiv: {
    margin: '0 auto',
    width: '70%',
    [theme.breakpoints.down('md')]: {
      width: '100%',
    },
  },
}));

const Helper = (props) => {
  const classes = useStyles();
  const { handleOnCLick } = props;

  const [coiNumber, setCoiNumber] = useState(null);
  const [mobileNo, setMobileNumber] = useState(null);
  const [disableButton, setDisableButton] = useState(true);
  const [mobNumErr, setMobNumErr] = useState('');

  const validateMoNumber = (number) => {
    const mobileNumberRegex = /^[0-9]{10}$/;
    if (!mobileNumberRegex.test(number)) {
      setMobNumErr('Enter valid mobile number');
    } else {
      setMobNumErr('');
    }
  };
  const handleMobNumChange = (e) => {
    const { value } = e.target;
    setMobileNumber(value);
    validateMoNumber(value);
  };
  useEffect(() => {
    if (!coiNumber || mobNumErr || !mobileNo) {
      setDisableButton(true);
    } else {
      setDisableButton(false);
    }
  });
  return (
    <div className={classes.parentDiv}>
      <div
        style={{
          fontWeight: 'bold',
          // padding: '8px',
          textAlign: 'center',
          fontSize: 'x-large',
        }}>
        Enter Nominee Details
      </div>
      <form
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: 20,
          marginTop: '60px',
          paddingLeft: '16px',
          paddingRight: '16px',
        }}>
        <div>
          <TextField
            fullWidth
            id='coi '
            variant='standard'
            placeholder='COI Number*'
            value={coiNumber}
            onChange={(e) => setCoiNumber(e.target.value)}
            error={coiNumber === ''}
            helperText={coiNumber === '' ? 'Please enter a coi number!' : ' '}
          />
        </div>
        <div>
          <TextField
            fullWidth
            id='num'
            variant='standard'
            placeholder='Mobile Number*'
            value={mobileNo}
            onChange={handleMobNumChange}
            error={mobileNo === '' || mobNumErr}
            helperText={
              mobileNo === ''
                ? 'Please enter a mobile number!'
                : ' ' && mobNumErr
                ? 'Mobile number must be 10 digits!'
                : ''
            }
          />
        </div>
        <div style={{ display: 'flex', justifyContent: 'center' }}>
          <Button
            onClick={() => {
              handleOnCLick(coiNumber, mobileNo);
            }}
            size='large'
            variant='contained'
            disabled={disableButton}
            style={{
              borderRadius: '24px',
              backgroundColor: disableButton ? '#7C88B3' : '#35488A',
              color: '#ffff',
            }}>
            Send Otp
          </Button>
        </div>
      </form>
    </div>
  );
};
export default Helper;
