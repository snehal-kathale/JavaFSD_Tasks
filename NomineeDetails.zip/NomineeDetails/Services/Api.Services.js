import {
  API_CLIENTID,
  API_HOST,
  NOMINEE_BASE_URL,
  NOMINEE_CLIENT_ID,
} from 'app/util/Config';
import { getLocalStorageItem } from 'app/util/localStorageHelper';
import axios from 'axios';
class _ApiService {
  postGenerateOtp = (params = {}) => {
    return axios({
      method: 'post',
      headers: {
        'Content-Type': 'application/json',
        clientId: `${API_CLIENTID}`,
      },
      url: `${API_HOST}/api/services/authentication/token/otp/generateOtp`,

      data: {
        ...params,
      },
    });
  };
  postToken = (data) => {
    return axios({
      method: 'post',
      headers: {
        'Content-Type': 'application/json',
      },
      data: data,
      url: `${NOMINEE_BASE_URL}/shgateway/auth/token/v1/generate`,
    });
  };
  postNomineeDetails = (params = {}, authToken, tokenType) => {
    const authData = JSON.parse(getLocalStorageItem('authData'));
    return axios({
      method: 'post',
      headers: {
        clientId: `${NOMINEE_CLIENT_ID}`,
        Authorization: `${authData.tokenType} ${authData.authToken}`,
      },
      url: `${NOMINEE_BASE_URL}/shgateway/common/policy/v1/details`,
      data: {
        ...params,
      },
    });
  };
  postUpdateNominee = (params = {}) => {
    const authData = JSON.parse(getLocalStorageItem('authData'));
    return axios({
      method: 'post',
      headers: {
        ClientId: `${NOMINEE_CLIENT_ID}`,
        Authorization: `${authData.tokenType} ${authData.authToken}`,
      },
      url: `${NOMINEE_BASE_URL}/shgateway/proposal/coi/v1/update/nominee`,
      data: {
        ...params,
      },
    });
  };
}
const ApiService = new _ApiService();

export { ApiService };
