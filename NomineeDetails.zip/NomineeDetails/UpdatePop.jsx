import React from 'react';
// import {
//   Button,
//   Dialog,
// } from '../../../../node_modules/@material-ui/core/index';
import Dialog from '@mui/material/Dialog';
import SuccessImg from '../../../assets/img/SuccessIcon.jpg';
import Button from '@mui/material/Button';

const UpdatePop = ({ handleClose, open, dialogOpen }) => {
  return (
    <div>
      <Dialog
        // show={true}
        open={open}
        title={'Success'}
        onClose={handleClose}
        keepMounted
        aria-describedby='simple-modal-slide-description'>
        <div
          style={{
            borderRadius: 4,
            padding: 50,
            display: 'flex',
            alignItems: 'center',
            flexDirection: 'column',
            gap: 20,
          }}>
          <img
            style={{ marginTop: 'auto', marginBottom: 'auto', width: '30%' }}
            src={SuccessImg}
          />
          <div style={{ textAlign: 'center' }}>
            You have successfully updated your nominee details
          </div>
          <div
            style={{
              display: 'flex',
              gap: 20,
              alignItems: 'center',
            }}>
            <Button
              variant='outlined'
              color='primary'
              onClick={handleClose}
              style={{
                borderRadius: '20px',
              }}>
              Ok
            </Button>
          </div>
        </div>
      </Dialog>
    </div>
  );
};

export default UpdatePop;
