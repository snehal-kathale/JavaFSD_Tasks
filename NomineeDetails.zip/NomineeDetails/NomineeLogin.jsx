import {
  PORTAL_FLAG,
  APP_BASE_PATH,
  NOMINEE_CLIENT_ID,
  NOMINEE_SECRET_KEY,
  NOMINEE_API_KEY,
  NOMINEE_GRANT_TYPE,
} from 'app/util/Config';
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import { Hidden } from '../../../../node_modules/@material-ui/core/index';
import CartCarousel from 'ps-components/CartCarousel/CartCarousel';
import { Grid } from '@mui/material';
import Helper from './Helper';
import ModalForm from 'ps-components/ModalForm/ModalForm';
import { ApiService } from './Services/Api.Services';
import VerifyOtpPopUp from './VerifyOtpPopUp';
import { navigate } from '@reach/router';
import AlertBox from './AlertBox';
import { setLocalStorageItem } from 'app/util/localStorageHelper';
import { Dialog } from '@material-ui/core';
import { createTheme } from '@mui/material/styles';

const useStyles = createTheme({
  modalRoot: {
    overflow: 'auto',
    display: 'block',
  },
  modal: {
    background: 'transparent !important',
    boxShadow: 'none !important',
  },
});
const classess = useStyles();
class NomineeLogin extends Component {
  constructor(props) {
    super(props);
    this.state = {
      errAlert: false,
      otpString: '',
      loading: false,
      otpSent: false,
      otp: false,
      mobileNo: '',
      coiNo: '',
      userId: '',
      serviceType: 'prelogin',
      appType: 'appType',
      function: 'type',
      email: '',
      nomineeDetailsData: '',
      name: '',
      token: '',
      tokenType: '',
      errMsg: '',
    };
  }

  loginUser = (coiNumber, mobileNo) => {
    this.setState({
      loading: true,
    });
    this.setState({ mobileNo });
    // let params = {};
    // params = {
    //   coiNumber: coiNumber,
    //   mobileNumber: mobileNo,
    // };
    const FormData = require('form-data');
    let data = new FormData();
    data.append('clientId', `${NOMINEE_CLIENT_ID}`);
    data.append('secretKey', `${NOMINEE_SECRET_KEY}`);
    data.append('apiKey', `${NOMINEE_API_KEY}`);
    data.append('grantType', `${NOMINEE_GRANT_TYPE}`);

    ApiService.postToken(data)
      .then((response) => {
        if (response?.data?.status === 'OK') {
          const authToken = response.data.accessToken;
          const tokenType = response.data.tokenType;
          this.setState({
            token: authToken,
            tokenType: tokenType,
            loading: false,
          });
          setLocalStorageItem(
            'authData',
            JSON.stringify({ authToken, tokenType })
          );

          let params = {};
          params = {
            mobileNumber: mobileNo,
            coiNumber: coiNumber,
          };
          ApiService.postNomineeDetails(params)
            .then((response) => {
              if (response?.data?.isNomineeUpdated === 'N') {
                this.setState({
                  coiNo: response?.data?.coiNumber,
                  name: response?.data?.firstName,
                  email: response?.data?.emailId,
                });

                setLocalStorageItem(
                  'loginData',
                  JSON.stringify({ coiNumber, mobileNo })
                );

                params = {
                  policyno: coiNumber,
                  mobileNo: mobileNo,
                  serviceType: 'prelogin',
                };
                ApiService.postGenerateOtp(params)
                  .then((response) => {
                    if (response.data.status === 'success') {
                      this.setState({
                        loading: false,
                        otpString: response.data.prefillString,
                        otpSent: true,
                      });
                    } else {
                      this.setState({
                        errMsg: response?.data?.errorMessage,
                        errAlert: true,
                      });
                    }
                  })
                  .catch((error) => {
                    this.setState({
                      errMsg: error?.response?.data?.errorMessage,
                      errAlert: true,
                    });
                  });
              } else {
                this.setState({
                  errMsg: response?.data?.errorMessage,
                  errAlert: true,
                });
              }
            })
            .catch((error) => {
              this.setState({
                errMsg: error?.response?.data?.errorMessage,
                errAlert: true,
              });
            });
        } else {
          this.setState({
            errAlert: true,
            errMsg: response?.data?.errorMessage,
          });
        }
      })
      .catch((error) => {
        this.setState({
          errMsg: error?.response?.data?.errorMessage,
          errAlert: true,
        });
      });
  };
  handleAlertClose = () => {
    this.setState({
      errAlert: false,
    });
  };
  handleClose = () => {
    this.setState({
      otpSent: false,
    });
  };
  handleOpen = () => {
    this.setState({
      otp: true,
    });
  };
  verifyOtpCompleted = () => {
    this.setState({
      otpSent: false,
    });
    navigate(`${APP_BASE_PATH}/nomineeUpdate/detailsForm`);
  };
  initiateOtpFlow = async (mobile) => {
    //check user account associated with mobile
    const validationResponse = await this.props.validateUserMobile(mobile);
    // console.log("validation response", validationResponse);
    //if associated - show otp modal
    if (validationResponse.isValid) {
      this.setState({
        otp: true,
      });
    }
  };

  render() {
    const { classes, user, thirdPartyAuth } = this.props;

    if (PORTAL_FLAG) {
      return (
        <>
          <Grid container className={classes.loginbottomStyle}>
            <Grid item md={8} xs={12} sm={10} className={classes.logincardView}>
              <Card
                className={classes.cardSignup}
                style={{
                  padding: `0`,
                }}
                sx={(theme) => ({
                  [theme.breakpoints.down('md')]: {
                    marginTop: '15vh',
                    paddingTop: '20px !important',
                    '& .nomineeForm': {
                      display: 'block',
                    },
                  },
                })}>
                <CardContent style={{ padding: `0` }}>
                  <Grid container style={{}}>
                    <Grid item md={12} style={{ width: '100%' }}>
                      <Grid
                        container
                        spacing={0}
                        className='nomineeForm'
                        alignItems='center'
                        justify='center'>
                        <Hidden mdDown>
                          <Grid item md={5} style={{ paddingLeft: `0` }}>
                            <CartCarousel></CartCarousel>
                          </Grid>
                        </Hidden>
                        <Grid
                          item
                          xs={10}
                          sm={10}
                          md={7}
                          style={{ maxWidth: '100%', width: '100%' }}>
                          <Helper
                            handleOnCLick={this.loginUser}
                            handleOpen={this.handleOpen}
                          />
                          {/* Open model after otp sent */}

                          <ModalForm
                            show={this.state.otpSent}
                            title={'OTP Validation'}
                            handleClose={() => {
                              this.handleClose();
                            }}>
                            <VerifyOtpPopUp
                              modalScreen
                              otpString={this.state.otpString}
                              mobile={this.state.mobileNo}
                              name={this.state.name}
                              verifyOtpCompleted={() => {
                                this.verifyOtpCompleted();
                              }}
                              redirect='/nomineeUpdate/detailsForm'></VerifyOtpPopUp>
                          </ModalForm>
                          {this.state.errAlert && (
                            <AlertBox
                              errMsg={this.state.errMsg}
                              errAlert={this.state.errAlert}
                              onClick={this.handleAlertClose}
                            />
                          )}
                          {/* {this.state.loading ? (
                            <Dialog
                              classes={{
                                root: classess.modalRoot,
                                paper: classess.modal,
                              }}
                              open
                              keepMounted
                              aria-describedby='simple-modal-slide-description'>
                              <img src={StarLoading} />
                            </Dialog>
                          ) : null} */}
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </>
      );
    }
  }
}
NomineeLogin.propTypes = {
  actions: PropTypes.object.isRequired,
  appMode: PropTypes.object.isRequired,
  classes: PropTypes.any.isRequired,
  location: PropTypes.any,
  thirdPartyAuth: PropTypes.any,
  uri: PropTypes.string,
};
export default NomineeLogin;
