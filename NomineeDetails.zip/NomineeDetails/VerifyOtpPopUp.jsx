import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { navigate } from '@reach/router';
import { STATIC_ASSET_BASE_PATH } from 'index';
import withStyles from '@material-ui/core/styles/withStyles';
import signupPageStyle from 'assets/jss/material-kit-pro-react/views/signupPageStyle';
import GridContainer from '@ps/star-ui/components/Grid/GridContainer';
import GridItem from '@ps/star-ui/components/Grid/GridItem';
import Button from '@ps/star-ui/components/CustomButtons/Button';
import { verifySeperateOtp } from 'app/api/postLoginOtp';
import { generatePreLoginOtp, ResendOtp } from 'app/api/preLoginOtp';
import CustomSnackbar from '@ps/star-ui/components/Snackbar/Snackbar';
import { APP_BASE_PATH } from 'app/util/Config';
import OtpInput from 'react-otp-input';
import Dialog from '@material-ui/core/Dialog';
import AlertBox from './AlertBox';

const StarLoading = 'static/star2_white.gif';

class VerifyOtpPopUp extends Component {
  state = {
    loading: false,
    enableEmailButton: false,
    enableSMSButton: false,
    otpSent: false,
    otpSentErr: false,
    wrongOtp: false,
    otpVerified: false,
    requestFailure: false,
    resendEnable: true,
    otp: ``,
    otpFailure: false,
    exceedLimit: false,
    errAlert: false,
  };

  sendOtp = async (mobile, email = null, userId = null, isResend) => {
    this.setState({
      loading: true,
      otp: '',
    });

    let response;

    if (!isResend || this.state.exceedLimit) {
      response = await generatePreLoginOtp(mobile);
    } else {
      response = await ResendOtp(mobile, email, userId);
    }

    this.setState({
      loading: false,
    });
    if (response.status === 'success') {
      this.setState({
        otpSent: true,
        otpString: response.prefillString,
        exceedLimit: false,
      });
    } else if (
      response.status === 'failure' &&
      response.message &&
      response.message.startsWith('#ERR')
    ) {
      this.setState({
        errAlert: true,
        otpSentErr: true,
        otpSentErrMsg: response.message,
      });
    } else if (
      response.status === 'failure' &&
      response.message &&
      response.message == 'OTP Expired, please click Generate OTP link.'
    ) {
      this.setState({
        loading: false,
        errAlert: true,
        exceedLimit: true,
        wrongOtp: true,
        errMsg: response.message,
      });
    } else if (response.status === 'failure' && response.message) {
      this.setState({
        errAlert: true,
        otpSentErr: true,
        otpSentErrMsg: response.message,
      });
    }

    this.setState({
      resendEnable: true,
    });
    setTimeout(() => {
      this.setState({
        resendEnable: false,
      });
    }, 60000);
  };

  resetWrongOtpFlag = () => {
    this.setState({
      wrongOtp: false,
    });
  };

  resetOtpFlag = () => {
    this.setState({
      otpSent: false,
      otpSentErr: false,
    });
  };

  componentDidMount = async () => {
    window.scrollTo(0, 0);
    const { mobile, redirect, fromPage, email, userId } = this.props;
    const appType = 'AuthIdentityOTP';
    let redirectPath = `${redirect}`;
    // this.sendOtp(mobile, appType, email, '', userId);
    setTimeout(() => {
      this.setState({
        resendEnable: false,
      });
    }, 60000);

    if (this.props.setBackButton) {
      let backPath = '';
      switch (fromPage) {
        case '/edit-profile':
          backPath = this.props.location.pathname;
          break;
        case '/proposal-otp':
          backPath = fromPage;
          break;
        case '/register/details':
          backPath = '/register/details';
        case '/login':
          backPath = '/login';
        default:
          backPath = '/renewal-contact';
          break;
      }
      this.props.setBackButton(
        `${backPath}`,
        this.props.location.search,
        'Verify OTP'
      );
    }
  };

  handleChange = (otp) => {
    if (otp.length === 5 && otp.search(`^[0-9]*$`) === 0) {
      this.setState({
        enableButton: true,
        otp,
      });
    } else if (otp.search(`^[0-9]*$`) === 0 && otp.length <= 6) {
      this.setState({
        enableButton: false,
        otp,
      });
    }
  };

  handleVerifyProposalOtp = async (redirect, response) => {
    this.props.verifyOtpCompleted(response);
  };

  handleActionSubmit = (redirectPath) => {
    navigate(`${APP_BASE_PATH}${redirectPath}`);
  };

  handleVerify = async (
    mobile,
    smsOtp,
    redirectPath,
    email,
    emailOtp,
    fromPage
  ) => {
    this.setState({
      loading: true,
    });
    let otpRequuest = {
      serviceType: 'prelogin',
      mobileNo: mobile,
      otp: smsOtp,
    };
    const response = await verifySeperateOtp(otpRequuest);
    if (response.status === 'success') {
      this.setState({
        loading: false,
      });
      this.handleVerifyProposalOtp(redirectPath);
    } else if (
      response.status === 'failure' &&
      response.message &&
      response.message.startsWith('#ERR')
    ) {
      this.setState({
        otpSentErr: true,
        otpSentErrMsg: response.message,
        loading: false,
      });
    } else {
      this.setState({
        loading: false,
        wrongOtp: true,
      });
    }
  };
  render() {
    let {
      classes,
      modalScreen,
      mobile,
      redirect,
      fromPage,
      email,
      userId,
      name,
    } = this.props;
    const appType = 'AuthIdentityOTP';
    let redirectPath = redirect;

    let mobileUi = '';
    if (mobile) mobile = mobile.slice(-10);

    for (let i = 0; i < mobile.length; i += 4) {
      mobileUi += mobile[i] + mobile[i + 1];
      if (i !== mobile.length - 2) {
        mobileUi += '**';
      }
    }

    let emailUi, emailBefore, emailAfter;
    if (email && email.length > 0) {
      emailUi = '';
      emailBefore = email && email.split('@')[0];
      emailAfter = email && email.split('@')[1];
      for (let i = 0; i < emailBefore.length; i++) {
        if (i < 2) emailUi += email[i];
        else emailUi += '*';
        if (i == 6) break;
      }
      emailUi += `@${emailAfter}`;
    }
    let emailData = '';
    if (emailUi != undefined && emailUi.length > 0) {
      emailData = `and ${emailUi}`;
    }
    return (
      <>
        <div
          style={{
            height: `${modalScreen ? '100%' : '100vh'}`,
            backgroundColor: 'white',
            padding: `${modalScreen ? '0px' : '22px'}`,
            overflow: `${modalScreen ? 'hidden' : 'scroll'}`,
            position: 'relative',
            paddingTop: `${modalScreen ? '10px' : ''}`,
          }}>
          <div
            className={classes.container}
            style={{ padding: `${modalScreen ? '0px' : ''}` }}>
            <GridContainer justify='center'>
              <GridItem xs={12} sm={12} md={12} className={classes.textCenter}>
                {this.state.loading && (
                  <Dialog
                    classes={{
                      root: classes.modalRoot,
                      paper: classes.modal,
                    }}
                    disableEnforceFocus={true}
                    disableAutoFocus={true}
                    open
                    keepMounted
                    aria-describedby='simple-modal-slide-description'>
                    <img src={`${STATIC_ASSET_BASE_PATH}${StarLoading}`} />
                  </Dialog>
                )}
                <GridItem
                  xs={12}
                  sm={12}
                  md={12}
                  className={classes.textCenter}
                  style={{ paddingLeft: '0px', paddingRight: '0px' }}>
                  {name && (
                    <h2
                      style={{
                        fontWeight: 200,
                        color: 'black',
                      }}>
                      Hi {name}.
                    </h2>
                  )}
                  <h3
                    style={{
                      fontWeight: 200,
                      color: 'black',
                    }}>
                    We have sent you the OTP to
                  </h3>
                  <h3
                    style={{
                      fontWeight: 200,
                      color: 'black',
                    }}>
                    {`${mobileUi}`}
                  </h3>
                </GridItem>

                {this.props.imageSrc && (
                  <GridItem
                    xs={12}
                    sm={12}
                    md={12}
                    className={classes.textCenter}>
                    <img
                      src={`${STATIC_ASSET_BASE_PATH}${this.props.imageSrc}`}
                      alt={this.props.imageAlt}
                    />
                  </GridItem>
                )}
                <br />
                <br />
                <form
                  className={classes.form}
                  onSubmit={(e) => {
                    e.preventDefault();
                    this.handleVerify(
                      mobile,
                      this.state.otp,
                      fromPage,
                      redirectPath,
                      email
                    );
                  }}>
                  <div style={{ display: 'flex', justifyContent: 'center' }}>
                    <p style={{ margin: '0px' }}>
                      <OtpInput
                        value={this.props.otpString + this.state.otpString}
                        numInputs={3}
                        containerStyle={{
                          justifyContent: `center`,
                        }}
                        inputStyle={{
                          fontSize: `1.25rem`,
                          border: `0`,
                          width: `100%`,
                          maxWidth: `45px`,
                          borderBottom: `1px solid`,
                          color: '#35488a',
                        }}
                        separator={<span>&nbsp;&nbsp;&nbsp;</span>}
                        isDisabled
                      />
                    </p>
                    &nbsp;&nbsp;
                    <OtpInput
                      onChange={(otp) => this.handleChange(otp)}
                      value={this.state.otp}
                      numInputs={5}
                      containerStyle={{
                        justifyContent: `center`,
                      }}
                      inputStyle={{
                        fontSize: `1.25rem`,
                        border: `0`,
                        width: `100%`,
                        maxWidth: `45px`,
                        borderBottom: `1px solid`,
                        color: `#555`,
                      }}
                      separator={<span>&nbsp;&nbsp;&nbsp;</span>}
                    />
                  </div>

                  <br />
                  <div className={classes.textCenter}>
                    <Button
                      className={'verify-otp'}
                      name='submitOtpBtn'
                      round
                      onClick={() =>
                        this.handleVerify(
                          mobile,
                          this.props.otpString + this.state.otp,
                          fromPage,
                          redirectPath,
                          email
                        )
                      }
                      disabled={!this.state.enableButton}
                      color='primary'
                      style={{
                        fontWeight: 900,
                        width: `${modalScreen ? '' : '100%'}`,
                        marginBottom: '28px',
                        fontSize: '17px',
                      }}>
                      Verify
                    </Button>
                  </div>
                </form>
              </GridItem>
              <GridItem xs={12} sm={12} md={12}>
                <div className={classes.textCenter}>
                  <h4
                    className={classes.socialTitle}
                    style={{
                      color: 'rgba(0, 0, 0, 0.73)',
                      fontSize: '17px',
                    }}>
                    Did not receive OTP?
                  </h4>
                  <Button
                    simple
                    onClick={() => {
                      this.sendOtp(mobile, appType, email, '', userId, true);
                    }}
                    className={classes.socialTitle}
                    style={{ color: 'black', fontWeight: 400 }}
                    disabled={this.state.resendEnable}>
                    {this.state.exceedLimit ? 'Generate Otp' : 'Resend'}
                  </Button>
                </div>
              </GridItem>
            </GridContainer>
          </div>

          {this.state.otpSentErr && (
            <div
              style={{
                width: `100%`,
                paddingLeft: `15px`,
                paddingRight: `15px`,
              }}>
              <CustomSnackbar
                open={this.state.otpSentErr}
                duration={3000}
                status={`error`}
                message={this.state.otpSentErrMsg}
                style={{ position: `relative`, marginBottom: `25px` }}
                flag={this.resetOtpFlag}
              />
            </div>
          )}
          {this.state.otpSent && (
            <div
              style={{
                width: `100%`,
                paddingLeft: `15px`,
                paddingRight: `15px`,
              }}>
              <CustomSnackbar
                open={this.state.otpSent}
                duration={3000}
                status={`success`}
                message={`OTP sent to ${mobileUi}`}
                style={{ position: `relative`, marginBottom: `25px` }}
                flag={this.resetOtpFlag}
              />
            </div>
          )}

          {this.state.wrongOtp && (
            <div
              style={{
                width: `100%`,
                paddingLeft: `15px`,
                paddingRight: `15px`,
              }}>
              <CustomSnackbar
                open={this.state.wrongOtp}
                duration={3000}
                status={`error`}
                message={this.state.errMsg}
                style={{ position: `relative`, marginBottom: `25px` }}
                flag={this.resetWrongOtpFlag}
              />
            </div>
          )}
          {this.state.errAlert && <AlertBox />}
        </div>
      </>
    );
  }
}

VerifyOtpPopUp.propTypes = {
  actions: PropTypes.object.isRequired,
  classes: PropTypes.any.isRequired,
  user: PropTypes.object,
};

export default withStyles(signupPageStyle)(VerifyOtpPopUp);
