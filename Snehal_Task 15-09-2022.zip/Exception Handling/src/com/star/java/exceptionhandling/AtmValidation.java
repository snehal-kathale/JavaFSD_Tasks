package com.star.java.exceptionhandling;

import java.util.Scanner;

public class AtmValidation {
	public static void main(String[] args) {
		
	/*int AccNo;
	System.out.println("Enter Account Number");*/
	
	
	
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter Your PIN");
		String pin = sc.next();
		if(pin.equals("1022")) {
			System.out.println("Pin is validate");
		}
		else {
			try {
				throw new IncorrectPin("Pin is incorrect");
			
		}catch(IncorrectPin e) {
			System.out.println(e);
			System.out.println("Please Enter Correct Pin ");
			
			
			
		}

	}
	}
}


