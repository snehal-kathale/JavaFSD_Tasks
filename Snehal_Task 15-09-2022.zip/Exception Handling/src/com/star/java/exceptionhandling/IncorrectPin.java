package com.star.java.exceptionhandling;

public class IncorrectPin extends RuntimeException{
	public IncorrectPin(String msg) {
		super(msg);
	}

}
