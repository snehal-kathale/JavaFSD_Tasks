package com.starhealth.datatypes.primitive;

import java.lang.*;

public class Test {
    public static void main(String[] args){
        Student s1= new Student("Sumit", 101,70.66);
        Student s2= new Student("Nitesh",102, 85.2);
        Student s3= new Student();
        s3.setName("Snehal");
        s3.setRollNo(103);
        s3.setPercentage(91.66);
        System.out.println(s1.getName()+", "+s1.getRollNo()+", "+s1.getPercentage());
        System.out.println(s2.getName()+", "+s2.getRollNo()+", "+s2.getPercentage());
        System.out.println(s3.getName()+", "+s3.getRollNo()+", "+s3.getPercentage());
    }
}
