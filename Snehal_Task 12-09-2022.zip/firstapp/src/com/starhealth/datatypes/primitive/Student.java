package com.starhealth.datatypes.primitive;
class Student extends Object {
    protected  String name;
    protected int rollNo;
    protected double percentage;

    public Student() {
        super();
    }

    public Student(String name, int rollNo, double percentage) {
        this.name = name;
        this.rollNo = rollNo;
        this.percentage = percentage;

    }

    public String getName() {
        return name;
    }

    public int getRollNo() {
        return rollNo;
    }

    public double getPercentage() {
        return percentage;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRollNo(int rollNo) {
        this.rollNo = rollNo;
    }

    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }
}


