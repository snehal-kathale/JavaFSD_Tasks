package com.starhealth;

public class Student1 extends Object{
    protected  static String name;
    protected static int rollNo;
    protected static double percentage;

    public Student1() {
        super();
    }

    public Student1(String name, int rollNo, double percentage) {
        this.name = name;
        this.rollNo = rollNo;
        this.percentage = percentage;

    }

    public String getName() {
        return name;
    }

    public int getRollNo() {
        return rollNo;
    }

    public double getPercentage() {
        return percentage;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRollNo(int rollNo) {
        this.rollNo = rollNo;
    }

    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }
}


