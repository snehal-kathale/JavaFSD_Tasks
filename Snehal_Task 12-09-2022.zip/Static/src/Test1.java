
import com.starhealth.Student1;

import java.lang.*;

public class Test1 {
    public static void main(String[] args){
        Student1 s1= new Student1("Sumit", 101,70.66);
        Student1 s2= new Student1("Nitesh",102, 85.2);
        Student1 s3= new Student1();
        s3.setName("Snehal");
        s3.setRollNo(103);
        s3.setPercentage(91.66);
        System.out.println(s1.getName()+", "+s1.getRollNo()+", "+s1.getPercentage());
        System.out.println(s2.getName()+", "+s2.getRollNo()+", "+s2.getPercentage());
        System.out.println(s3.getName()+", "+s3.getRollNo()+", "+s3.getPercentage());
    }
}