package com.library;

public class Wrapper {
    public static void main(String[] args) {

        int n1= 12;
        String s= "12";
        Integer i = new Integer(12);



        Integer j = new Integer("12");

        String s1 = i.toString();

    }

}
