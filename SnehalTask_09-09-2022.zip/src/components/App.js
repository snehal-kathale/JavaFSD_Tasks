import React from "react";

function App(){
    const name = "Good Start of the day with react";
    return(
        <div>{name}</div>
    );
}

export default App;