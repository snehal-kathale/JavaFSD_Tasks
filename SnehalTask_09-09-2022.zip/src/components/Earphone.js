import React from "react";

class Earphone extends React.Component{
    render(){
        return <h3>Earphones are good and working properly</h3>
    }
}

export default Earphone;